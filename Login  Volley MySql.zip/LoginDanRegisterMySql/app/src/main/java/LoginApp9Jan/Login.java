package LoginApp9Jan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.millenialzdev.logindanregistervolleymysql.R;

import org.json.JSONObject;
public class Login extends AppCompatActivity {

    private EditText etUsername, etPassword;
    private Button btnLogin;
    private RequestQueue requestQueue;
    private static final String BASE_URL = "http://10.0.2.2/loginapp/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        requestQueue = Volley.newRequestQueue(this);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String username = etUsername.getText().toString().trim();
                String password = etPassword.getText().toString().trim();

                if (!username.isEmpty() && !password.isEmpty()) {

                    JSONObject params = new JSONObject();
                    try {
                        params.put("username", username);
                        params.put("password", password);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                            Request.Method.POST,
                            BASE_URL + "login.php",
                            params,
                            new Response.Listener<JSONObject>() {
                                @Override
                                public void onResponse(JSONObject response) {
                                    Log.d("LoginResponse", response.toString()); // Tambahkan log ini
                                    try {
                                        String status = response.getString("status");
                                        if (status.equals("success")) {
                                            // Ambil data pengguna dari objek "data"
                                            JSONObject userData = response.getJSONObject("data");
                                            int id = userData.getInt("id");
                                            String username = userData.getString("username");
                                            int usia = userData.getInt("usia");
                                            String alamat = userData.getString("alamat");

                                            // Buat Intent untuk berpindah ke MainActivity
                                            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                            // Kirim data ke MainActivity
                                            intent.putExtra("id", id);
                                            intent.putExtra("username", username);
                                            intent.putExtra("usia", usia);
                                            intent.putExtra("alamat", alamat);
                                            startActivity(intent);
                                        } else {
                                            Toast.makeText(getApplicationContext(), "Login Gagal: " + response.getString("message"), Toast.LENGTH_SHORT).show();
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
                                }
                            }
                    );

                    requestQueue.add(jsonObjectRequest);

                } else {
                    Toast.makeText(getApplicationContext(), "Username atau password tidak boleh kosong", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}