package LoginApp9Jan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.millenialzdev.logindanregistervolleymysql.R;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private TextView tvUserData;
    private static final String BASE_URL = "http://10.0.2.2/loginapp/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvUserData = findViewById(R.id.tvUserData);

        // Ambil data dari Intent
        Intent intent = getIntent();
        int id = intent.getIntExtra("id", -1);
        String username = intent.getStringExtra("username");
        int usia = intent.getIntExtra("usia", -1);
        String alamat = intent.getStringExtra("alamat");

        // Menampilkan data user yang login pertama
        String userData = "ID: " + id + "\nUsername: " + username + "\nUsia: " + usia + "\nAlamat: " + alamat + "\n\n";
        tvUserData.setText(userData);

        // Load semua data users dari database
        loadAllUsers();
    }

    private void loadAllUsers() {
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.GET,
                BASE_URL + "get_users.php",
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray usersArray = response.getJSONArray("data");

                            StringBuilder dataBuilder = new StringBuilder(); // Menggunakan StringBuilder untuk menggabungkan data

                            for (int i = 0; i < usersArray.length(); i++) {
                                JSONObject userObject = usersArray.getJSONObject(i);
                                int id = userObject.getInt("id");
                                String username = userObject.getString("username");
                                int usia = userObject.getInt("usia");
                                String alamat = userObject.getString("alamat");

                                dataBuilder.append("ID: ").append(id)
                                        .append("\nUsername: ").append(username)
                                        .append("\nUsia: ").append(usia)
                                        .append("\nAlamat: ").append(alamat)
                                        .append("\n\n");
                            }

                            // Tambahkan data ke TextView
                            tvUserData.append("\nSemua Data Users:\n");
                            tvUserData.append(dataBuilder.toString());

                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(MainActivity.this, "Gagal memuat data", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(MainActivity.this, "Gagal memuat data", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        Volley.newRequestQueue(this).add(jsonObjectRequest);
    }
}
